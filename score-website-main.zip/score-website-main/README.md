### Installation

```
Open terminal
https://github.com/enactus-iitr/score-website.git
cd score-website
npm install
npm start
```
