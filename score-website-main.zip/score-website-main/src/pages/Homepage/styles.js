import { makeStyles } from '@material-ui/core/styles'

const useStyles = makeStyles({
  home: {
    background: '#fff'
  }
})

export default useStyles
