import { makeStyles } from '@material-ui/core/styles'

const useStyles = makeStyles({})

export default useStyles
