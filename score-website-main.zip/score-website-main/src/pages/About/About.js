import React from 'react'
import useStyles from './styles.js'

export default function About () {
  const classes = useStyles()

  return <div>ABOUT PAGE</div>
}
